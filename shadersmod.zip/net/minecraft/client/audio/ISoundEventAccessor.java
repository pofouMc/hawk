package net.minecraft.client.audio;

public interface ISoundEventAccessor {
   Object cloneEntry();

   int getWeight();
}
