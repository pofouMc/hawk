package hawk.settings;

import hawk.modules.Module;

public class Setting {
   public Module parent;
   public boolean focused;
   public String name;
}
