package hawk.events.listeners;

import hawk.events.Event;

public class EventUpdate extends Event<EventUpdate> {
}
