package hawk.events;

public enum EventDirection {
   private static final EventDirection[] ENUM$VALUES = new EventDirection[]{INCOMING, OUTGOING};
   INCOMING,
   OUTGOING;
}
