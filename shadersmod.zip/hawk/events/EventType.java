package hawk.events;

public enum EventType {
   private static final EventType[] ENUM$VALUES = new EventType[]{PRE, POST};
   PRE,
   POST;
}
