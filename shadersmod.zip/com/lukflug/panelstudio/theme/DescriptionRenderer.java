package com.lukflug.panelstudio.theme;

import com.lukflug.panelstudio.Context;

public interface DescriptionRenderer {
   void renderDescription(Context var1);
}
