package com.lukflug.panelstudio.tabgui;

interface package-info {
}
