package com.lukflug.panelstudio.hud;

interface package-info {
}
