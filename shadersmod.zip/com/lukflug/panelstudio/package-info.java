package com.lukflug.panelstudio;

interface package-info {
}
