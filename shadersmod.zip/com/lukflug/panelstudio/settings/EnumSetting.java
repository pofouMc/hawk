package com.lukflug.panelstudio.settings;

public interface EnumSetting {
   void increment();

   String getValueName();
}
