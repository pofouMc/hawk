package com.lukflug.panelstudio.settings;

interface package-info {
}
