package com.lukflug.panelstudio.settings;

public interface KeybindSetting {
   String getKeyName();

   int getKey();

   void setKey(int var1);
}
