package com.lukflug.panelstudio.settings;

public interface Toggleable {
   void toggle();

   boolean isOn();
}
