package com.lukflug.panelstudio.mc8forge;

interface package-info {
}
